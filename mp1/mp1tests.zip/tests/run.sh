#!/usr/bin/sh
#
# MP1 place in student directory
./lab1 3 < ../tests/t00testinput_3 > gradingout_t00testinput_3
./lab1 2 < ../tests/t01emptylist_2 > gradingout_t01emptylist_2
./lab1 10 < ../tests/t02quit_10 > gradingout_t02quit_10
./lab1 2 < ../tests/t03oneadd_2 > gradingout_t03oneadd_2
./lab1 4 < ../tests/t04oneaddremove_4 > gradingout_t04oneaddremove_4
./lab1 5 < ../tests/t05onereplace_5 > gradingout_t05onereplace_5
./lab1 9 < ../tests/t06nineadds_9 > gradingout_t06nineadds_9
./lab1 9 < ../tests/t07removes_9 > gradingout_t07removes_9
./lab1 9 < ../tests/t08removes_9 > gradingout_t08removes_9
./lab1 5 < ../tests/t09rejects_5 > gradingout_t09rejects_5
./lab1 5 < ../tests/t10removefail_5 > gradingout_t10removefail_5
./lab1 5 < ../tests/t11oneremoveall_5 > gradingout_t11oneremoveall_5
./lab1 9 < ../tests/t12incs_9 > gradingout_t12incs_9
./lab1 10 < ../tests/t13mixed_10 > gradingout_t13mixed_10
./lab1 34 < ../tests/t14random_34 > gradingout_t14random_34
./lab1 9 < ../tests/t15removalls_9 > gradingout_t15removalls_9
./lab1 5 < ../tests/t16nolist_5 > gradingout_t16nolist_5
./lab1 5 < ../tests/t17decs_5 > gradingout_t17decs_5

