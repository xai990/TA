#! /usr/bin/env python

import os
import sys
import subprocess
import signal
import string
import time


#Set testing constants
pre=""
#copy_files = ["makefile", "socketlist.h"]
copy_files = []
assign_num = 3
tparams="./tests.txt"
vtparams=""
#vtparams = ""

glog = "graderlog"
gvallog = "gradervallog"
makefile = "makefile"
Makefile = "Makefile"
clean = "make clean"
design = "make design"
valgrind = "valgrind --leak-check=yes --log-fd=1"

comp = 0
comp_clean = 0;
design_check = 0;
#Handle Command line Parameters#
arg_num = 1;
directories = []
directories = os.listdir(".")
directories = sorted(directories)
timeout = 10
MEGA_BYTES = 2**20
size_threshold = 50*MEGA_BYTES
while( arg_num < len(sys.argv)):
	arg = sys.argv[arg_num]
	if(arg == "-m"):	#Compile
		comp = 1
	elif(arg == "-u"):	#User
		arg_num = arg_num + 1
		if sys.argv[arg_num][-1] == ":":
			i = 0
			while directories[i] != sys.argv[arg_num][:-1]:
				i = i + 1
			directories = directories[i:]
		else :
			directories = [sys.argv[arg_num]]
	elif(arg == "-t"):
		arg_num = arg_num + 1
		timeout = string.atoi(sys.argv[arg_num])
	elif(arg == "-c"):
		comp_clean =1
	elif(arg == "-s" or arg == "-size_limit"):  #Log file size limit
		arg_num = arg_num + 1
		size_threshold = int(sys.argv[arg_num]) * MEGA_BYTES
	elif(arg == "-d"):
		design_check = 1
	elif(arg == "-a"):  #Assignment Num
		arg_num = arg_num + 1
		assign_num = int(sys.argv[arg_num])
	arg_num = arg_num + 1

#Set the proper file Names
#main = "lab%d.c" % assign_num
exe = "./lab%d" % assign_num
'''		
if(len(sys.argv) > 2):
	timeout = string.atoi(sys.argv[2])
else:
	timeout = 10

if(len(sys.argv) > 1):
	if sys.argv[1] != 'compile':
		if sys.argv[1] == 'all':
			directories = []
			directories = os.listdir(".")
			directories = sorted(directories)
		else:
			directories = [sys.argv[1]]

	else:
		comp = 1
		directories = []
		directories = os.listdir(".")
		directories = sorted(directories)
else:
	directories = []
	directories = os.listdir(".")
	directories = sorted(directories)
'''
#Set Up Alarm Handler#	
def handler(signum, frame):
    global p
    print "-------------------------------"
    print "\t--Infinite loop"
    print "-------------------------------"    
    p.kill()
    print p.returncode
    global err
    signal.alarm(0)
    err = 1



signal.signal(signal.SIGALRM, handler)
global p
global err
err = 0

tests = 0
valtests = 0

if os.path.isfile(tparams):
	if os.path.isfile("test1.sh"):
		os.system("rm test*.sh")
	params = open(tparams, "r")
	for line in iter(params.readline,  ''):
		if line[0] == "#":
			continue
		tests = tests + 1
		t = open("test%d.sh" % tests, "w")
		t.write("#!/bin/bash\n")
		t.write(exe + " " + line)
		t.close()
		os.system("chmod +x test%d.sh" % tests)

if os.path.isfile(vtparams):
	params = open(vtparams, "r")
	if os.path.isfile("valtest1.sh"):
		os.system("rm valtest*.sh")
	for line in iter(params.readline,  ''):
		if line[0] == "#":
			continue
		valtests = valtests + 1
		t = open("valtest%d.sh" % valtests, "w")
		t.write("#!/bin/bash\n")
		t.write(valgrind + " " + exe + " " + line)
		t.close()
		os.system("chmod +x valtest%d.sh" % valtests)

for i in xrange(len(directories)):
	if os.path.isdir(directories[i]):
		os.chdir(directories[i])
		print "---------------------------------------------------------"
		print directories[i]
		print "---------------------------------------------------------"
		
		#Copy forgotten files if allowed
		for f in xrange(len(copy_files)):
			if not os.path.isfile(str( "./" + str(copy_files[f]))):
				os.system(str("cp ../" + str(copy_files[f]) + " ."))
		
		#Any Preprocessing needed
		if( pre != ""):
			p = subprocess.Popen(pre.split())
			p.wait()
		
		
		#Do Make clean
		if comp_clean == 1:
			p = subprocess.Popen(clean.split())
			p.wait()
			os.chdir("..")
			continue
		
		#Check for design violations
		if design_check == 1:
			p = subprocess.Popen(design.split())
			p.wait()
			os.chdir("..")
			continue
			
		#Compile
		files = os.listdir("./")
		for f in files:
			if( f[-2:] == ".c"):
				gcc = "gcc -Wall %s -o %s -lm" % (f, exe)
		p = subprocess.Popen(gcc.split())
		p.wait()
		if(os.path.isfile(exe) == False):
			print "\t---Does not Compile"
		
		#p.wait()
		if comp == 1:
			os.chdir("..")
			continue
		if os.path.isfile(exe):
			#Run no valgrind script
			params = ""
			test_params = open("../tests.txt", 'r')
			graderlog = open(glog, 'w')
			num = 1
			for q in xrange(1, tests+1):
				log = open('tmp.grade.log', 'w')
				graderlog.write("###### Test %d ######\n" % num)
				num = num + 1
				script = str("test" + str(q) + ".sh")
				os.system("cp ../%s ." % script)
				line = 'z'
				#print "./" + script
				signal.alarm(timeout)
				p = subprocess.Popen(str("./" + script).split(), stdout = log, stderr = log)
				print p.poll()
				while(p.poll() == None):
					if(os.path.getsize("./tmp.grade.log") >= size_threshold):
						p.kill()
						signal.alarm(0)
						log.close()
						os.remove("./tmp.grade.log")
						log = open('tmp.grade.log', 'w')
						log.write("TOO MUCH OUTPUT TEST ABORTED")
					time.sleep(0.05)
				
				signal.alarm(0)
				log = open('tmp.grade.log', 'r')
				for line in iter(log.readline,  ''):
					#sys.stdout.write(line)
					graderlog.write(line)
				log.close()
				os.remove("./tmp.grade.log")
			graderlog.close()
			
			if err is not 1:
				print "\t---Runs through"

			err = 0
			
			#Run valgrind script
			num = 0
			#test_params = open("../valtests.txt", "r")
			gradervallog = open(gvallog, "w")
			for q in xrange(1, valtests+1):
				log = open('tmp.val.log', 'w')
				gradervallog.write("###### Test %d ######\n" % num)
				num = num + 1
				script = str("./valtest" + str(q) + ".sh")
				os.system("cp .%s ." % script)
				line = 'z'
				signal.alarm(timeout)
				p = subprocess.Popen(script.split(), stdout = log, stderr = log)
				p.wait()
				signal.alarm(0)
				time.sleep(1)		##This helped keep valgrind from crashing
				log.close()
				log = open('tmp.val.log', 'r')
				for line in iter(log.readline,  ''):
					gradervallog.write(line)
				log.close
			
			gradervallog.close()
		else:
			print "\t---Does not compile"
		
		err = 0
		signal.alarm(0)
		os.chdir("..")
		#os.system("make")
		#os.popen('make').read()
		#os.system("./lab4 -e -w 10 -t 10 -a 1022 -r 0 -v")
		#os.popen('lab4')
		##Go to top of loop if not a directory


