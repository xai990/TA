/* ============================================================================
   lab3.c
   Ken Aliento
   kalient
   ECE 2220, Fall 2017
   MP3
   Subject: ECE222-1,#3

   Purpose: Takes in packets of data and reveals important information within
               like a password.

   Assumptions:
      #1   The user is prompted to enter two "packets."  The packets will have
            a maximum of 80 characters.

      #2:  The string and character type library cannot be used under
            any circumstances.  You are encouraged to develop your own
            functions to perform any similar operations that are needed.

      #3   No changes to the code in main.  Your code must be placed in
            functions.  Additional functions are encouraged.

   Bugs:

   Notes:

============================================================================ */

#include <stdio.h>

#define MAXPACKETSIZE 80

// ========================================================================= //
// ========================= PROTOTYPE FUNCTIONS =========================== //
// ========================================================================= //

int  process_input(const char *pwpacket, const char *keypacket,
                  char *encpw, char *enckey);
void decrypt_password(const char *encpw, const char *enckey, char *password);
int  process_packet(const char *packet, char *substr);
int  find_substr(const char *packet, const char escchar, char *sub);
int  str_len(const char *);
void str_concat(char *, char *);
int  is_alph(const char ch);
int char_map(const char ch);
char char_unmap(const int num);

// ========================================================================= //
// =============================== MAIN ==================================== //
// ========================================================================= //

int main() {
   char packet1[MAXPACKETSIZE];
   char packet2[MAXPACKETSIZE];
   char encpw[MAXPACKETSIZE];
   char enckey[MAXPACKETSIZE];
   char password[MAXPACKETSIZE];
   int  error_code;

   printf("\nMP3: Extracting and decrypting embedded passwords\n");
   printf("Inputs: Two at most 80 character \"packets.\"\n");
   printf("Escape characters: '%%', '$', and '*'\n");
   printf("\tCtrl-d to quit\n\n");

   // each call to fgets collects one line of input and stores in input_line
   // BEWARE: fgets includes the end-of-line character '\n' in input_line
   while ((fgets(packet1, sizeof packet1, stdin) != NULL)
            && (fgets(packet2, sizeof packet2, stdin) != NULL)) {

      // clear for next round
      encpw[0] = enckey[0] = password[0] = '\0';

      // print input packets
      printf("\npacket 1:\n%s\n", packet1);
      printf("packet 2:\n%s\n", packet2);

      // process input
      error_code = process_input(packet1, packet2, encpw, enckey);

      if(error_code == 0) {
         // print parsed input
         printf("encrypted password: %s\n", encpw);
         printf("encryption key:     %s\n", enckey);

         // perform decryption
         decrypt_password(encpw, enckey, password);

         // print decrypted password
         printf("decrypted password: %s\n\n", password);
      } else {
         printf("# ERROR: invalid input packets\n\n");
      }
   }
   printf("\nGoodbye\n");
   return 0;
}

// ========================================================================= //
// ======================== FUNCTION IMPLEMENTATION ======================== //
// ========================================================================= //


// ---------------------------- process_input ------------------------------ //
// Process Input
// Description - parse the two input packets
//
// Each packet contains up to 80 characters.  The first packet contains
// the encrypted password, and the second packet contains the encryption
// key.  Each of these two strings is broken into three pieces (substrings) in
// their respective packets - piece 1 is marked with '%'s, piece 2
// is marked with '$'s, and piece 3 is marked with '*'s.
//
// Parameters  - password packet arr (ptr)
//             - key packet arr (ptr)
//             - encrypted password arr (ptr)
//             - encrypted key arr (ptr)
// Return      - 1 if error, 0 if no error
//             - encrypted password arr (ptr)
//             - encrypted key arr (ptr)
// ------------------------------------------------------------------------- //
int process_input(const char *pwpacket, const char *keypacket,
                  char *encpw, char *enckey) {
   if (process_packet(pwpacket, encpw) == 1) return 1;
   if (process_packet(keypacket, enckey) == 1) return 1;
   if (str_len(encpw) != str_len(enckey)) return 1;
   return 0;   // return 0 if no errors
}


// --------------------------- decrypt_password ---------------------------- //
// Decrypt Password
// Description - perform decryption on the encrypted password using char add
//
// Each character is converted to an integer in the range 0...51, where a is 0,
// b is 1, c is 2, ..., z is 25, A is 26, B is 27, ..., Z is 51.  The
// decryption operation is then performed by adding the encryption key to the
// encrypted password using addition modulo 52.
//
// Parameters  - encrypted password arr (ptr)
//             - encrypted key arr (ptr)
//             - password arr (ptr)
// Assumptions - input has been verified in process_input
// Return      - password arr (ptr)
// ------------------------------------------------------------------------- //
void decrypt_password(const char *encpw, const char *enckey, char *password) {
   int i;
   int sum;
   for (i = 0; i < str_len(encpw); i++) {
      sum = char_map(encpw[i]) + char_map(enckey[i]);
      // printf("SUM %d\n", sum);      // DEBUG
      password[i] = char_unmap(sum % 52);
   }
   password[i] = '\0';
}


// ---------------------------- process_packet ----------------------------- //
// Process Packet
// Description - process packet by finding substrings (%, $, *) and
//             - concatenating them into one string
// Parameters  - packet array ptr
//             - substrings ptr (output)
// Return      - 0 if no error, 1 if any error
// ------------------------------------------------------------------------- //
int process_packet(const char *packet, char *substr3) {
   char substr[MAXPACKETSIZE];               // single substr arr
   substr3[0] = '\0';                        // reset substr3
   if (find_substr(packet, '%', substr) == 1) return 1;   // '%'
   str_concat(substr3, substr);
   if (find_substr(packet, '$', substr) == 1) return 1;   // '$'
   str_concat(substr3, substr);
   if (find_substr(packet, '*', substr) == 1) return 1;   // '*'
   str_concat(substr3, substr);
   return 0;   // return 0 if no errors
}


// ------------------------------ find_substr ------------------------------ //
// Find Substring
// Description - find substring in between escape characters
// Parameters  - packet array ptr
//             - escape character
//             - substring array ptr (output) w/ null char
// Return      - 1 if did not find two escape chars and substring doesn't
//                include alphabet characters only, 0 if successful
// ------------------------------------------------------------------------- //
int find_substr(const char *packet, const char escchar, char *sub) {
   int i, j;
   int charct = 0;
   sub[0] = '\0';
   for (i = 0, j = 0; i < MAXPACKETSIZE && charct < 2; i++) {
      if (packet[i] == escchar) {
         charct++;
      } else if (charct == 1) {
         if (is_alph(packet[i]) == 1)  // if a char in substr is not alpha
            charct = 3;                // set charct = 3 so indicates error
         sub[j] = packet[i];           // copy substr
         j++;
      }
   }
   sub[j] = '\0';
   // return 0 if found two escape characters, else return 1 (error)
   if (charct == 2)
      return 0;
   else
      return 1;
}


// ------------------------------ str_len ---------------------------------- //
// String Length
// Description - calculates how long a string is not including '\0'
// Parameters  - character array pointer
// Return      - length (int)
// ------------------------------------------------------------------------- //
int str_len(const char *str) {
   int len = 0;
   while (str[len] != '\0') {
      len++;
   }
   return len;
}


// ------------------------------ str_concat ------------------------------- //
// String Concatenation
// Description - concatenates strsrc to strdest
// Parameters  - char array ptr destination
//             - char array ptr src
// Return      - nothing
// ------------------------------------------------------------------------- //
void str_concat(char *strdest, char *strsrc) {
   int i, j;
   for (i = str_len(strdest), j = 0; j <= str_len(strsrc); i++, j++) {
      strdest[i] = strsrc[j];
   }
}


// ------------------------------- is_alph --------------------------------- //
// Is Alphabet?
// Description - checks if a char is an alphabet char (a-z, A-Z)
// Parameters  - character
// Return      - 0 if alphabet, 1 if not
// ------------------------------------------------------------------------- //
int is_alph(const char ch) {
   if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z'))
      return 0;
   else
      return 1;
}


// ------------------------------- char_map -------------------------------- //
// Map Character
// Description - converts char to an int... 'a'-'z' = 0-25; 'A'-'Z' = 26-51
// Parameters  - char
// Assumptions - char is an alphabet character
// Return      - int (mapped number), -1 in case of error
// ------------------------------------------------------------------------- //
int char_map(const char ch) {
   if (ch >= 'a' && ch <= 'z')
      return (int) ch - 'a';
   else if (ch >= 'A' && ch <= 'Z')
      return (int) ch - 'A' + 26;
   else
      return -1;
}


// ------------------------------ char_unmap ------------------------------- //
// Unmap Character
// Description - convert map # back to alph char
// Parameters  - mapped number
// Assumptions - input needs to be in range 0-51
// Return      - unmapped char, '\0' in case of error
// ------------------------------------------------------------------------- //
char char_unmap(const int num) {
   if (num >= 0 && num <= 25)
      return (char) num + 'a';
   else if (num >= 26 && num <= 51)
      return (char) num - 26 + 'A';
   else
      return '\0';
}
