#!/bin/bash
./lab3 < ../../tests/mp3tests
