/* lab3.c
 * Tom Birdsong
 * tbirdso
 * ECE 2220, Fall 2017
 * MP3
 * Subject: ECE222-1,#3
 *
 * Purpose:  Interpret encrypted transmission to return decrypted password
 *
 * Assumptions:
 *  #1   The user is prompted to enter two "packets."  The packets will have a
 *       maximum of 80 characters.
 *
 *  #2:  The string and character type library cannot be used under
 *       any circumstances.  You are encouraged to develop your own
 *       functions to perform any similar operations that are needed.
 *
 *  #3   No changes to the code in main.  Your code must be placed in
 *       functions.  Additional functions are encouraged.
 *
 * Bugs: None known
 *
 * Notes:
 *
 * See the ECE 2220 programming guide
 *
 * If your formatting is not consistent you must fix it.  You can easily
 * reformat (and automatically indent) your code using the astyle
 * command.  In a terminal on the command line do
 *
 *     astyle --style=kr lab3.c
 *
 * See "man astyle" for different styles.  Replace "kr" with one of
 * ansi, java, gnu, linux, or google to see different options.  Or, set up
 * your own style.
 */

// do not include any additional libraries
#include <stdio.h>

// do not change this constant
#define MAXPACKETSIZE 80
#define NUM_ESCAPE_CHARS 3
#define ESCAPE_REPEATS 2
#define NUM_PACKETS 2
#define NUM_INDICES 2
#define DECODE_MAP_LENGTH 52
#define UPPERCASE_MAP_OFFSET 26

// function prototypes
int process_input(const char *pwpacket, const char *keypacket, char *encpw, char *enckey);
void decrypt_password(const char *encpw, const char *enckey, char *password);
//custom string functions
int cstrlen(char *);
int cstrcpy(const char *, char *);
int cstrcharnum(const char *, char);
int cstrchar(const char *, char);
//other functions
int assembleHidden(const char *, int [NUM_ESCAPE_CHARS][NUM_INDICES], char *);
int mapCharInt(char *, int *);
int mapIntChar(int, int *, char *);

// do not change any code in main.  We are grading based on the format
// of the output as given in the printfs in main.
int main()
{
    char packet1[MAXPACKETSIZE];
    char packet2[MAXPACKETSIZE];
    char encpw[MAXPACKETSIZE];
    char enckey[MAXPACKETSIZE];
    char password[MAXPACKETSIZE];
    int  error_code;

    printf("\nMP3: Extracting and decrypting embedded passwords\n");
    printf("Inputs: Two at most 80 character \"packets.\"\n");
    printf("Escape characters: '%%', '$', and '*'\n");
    printf("\tCtrl-d to quit\n\n");

    // each call to fgets collects one line of input and stores in input_line
    // BEWARE: fgets includes the end-of-line character '\n' in input_line
    while ((fgets(packet1, sizeof packet1, stdin) != NULL)
            && (fgets(packet2, sizeof packet2, stdin) != NULL)) {

        // clear for next round
        encpw[0] = enckey[0] = password[0] = '\0';

        // print input packets
        printf("\npacket 1:\n%s\n", packet1);
        printf("packet 2:\n%s\n", packet2);

        // process input
        error_code = process_input(packet1, packet2, encpw, enckey);

        if(error_code == 0) {
            // print parsed input
            printf("encrypted password: %s\n", encpw);
            printf("encryption key:     %s\n", enckey);

            // perform decryption
            decrypt_password(encpw, enckey, password);

            // print decrypted password
            printf("decrypted password: %s\n\n", password);
        } else {
            printf("# ERROR: invalid input packets\n\n");
        }
    }
    printf("\nGoodbye\n");
    return 0;
}

/* Parse the two input packets.
 *
 * Each packet contains up to 80 characters.  The first packet contains
 * the encrypted password, and the second packet contains the encryption
 * key.  Each of these two strings is broken into three pieces (substrings) in
 * their respective packets - piece 1 is marked with '%'s, piece 2
 * is marked with '$'s, and piece 3 is marked with '*'s.
 *
 * Packets contain only printable characters.
 *
 * Input: The two packets are collected using fgets.  Recall the end-of-line
 *        character is included in the input string and marks the end of the
 *        input.  This string must not be changed.
 *
 * Output:  There are three outputs from this function.
 *
 *   The return value is an error code.  Error code 0 represents no error.
 *   Any other value is an error.
 *
 *  If there are no errors, then two strings are also returned.  The first,
 *  encpw, contains the encrypted password.  The second, enckey, contains
 *  the encryption key.  If an error occurs, these two output strings
 *  are undefined.
 */
int process_input(const char *pwpacket, const char *keypacket, char *encpw, char *enckey)
{
    int i, j, pwSize, keySize;
    int validPacketChars = 1, validNumEscapes = 1, validAssembly = 0;
    const int ERROR_CODE = -1, SUCCESS_CODE = 0;
    char encChar;
    char escapeChars[NUM_ESCAPE_CHARS] = {'%','$','*'};
    int escapeIndices[NUM_PACKETS][NUM_ESCAPE_CHARS][ESCAPE_REPEATS];
    int escapeOccurrences[NUM_PACKETS] = {0};
    const char *inPackets[NUM_PACKETS] = {pwpacket, keypacket};
    char *decodedPackets[NUM_PACKETS] = {encpw,enckey};

    for(i=0; i<NUM_PACKETS; i++) {
        if(!validNumEscapes || !validPacketChars)
            break;

        for(j = 0; j < NUM_ESCAPE_CHARS; j++) {
            escapeOccurrences[i] = cstrcharnum(inPackets[i],escapeChars[j]);
            if(escapeOccurrences[i]!=2) {
                validNumEscapes=0;
                break;
            }

            escapeIndices[i][j][0] = cstrchar(inPackets[i],escapeChars[j]);
            escapeIndices[i][j][1] = (escapeIndices[i][j][0]+1)+cstrchar((inPackets[i]+escapeIndices[i][j][0]+1),escapeChars[j]);
        }
    }
    if(!validNumEscapes)
        return ERROR_CODE;

    validAssembly = assembleHidden(inPackets[0],escapeIndices[0],encpw);
    validAssembly &= assembleHidden(inPackets[1],escapeIndices[1],enckey);
    if(!validAssembly)
        return ERROR_CODE;


    //Error checking
    pwSize = cstrlen(encpw);
    keySize = cstrlen(enckey);

    if(pwSize != keySize) {
        return ERROR_CODE;
    } else {
        for(i = 0; i < NUM_PACKETS; i++) {
            for(j = 0; j < pwSize; j++) {
                encChar = decodedPackets[i][j];
                if((encChar<'0'||encChar>'9')&&(encChar<'a'||encChar>'z')&&(encChar<'A'||encChar>'Z'))
                    validPacketChars=0;
            }
        }
        if(!validPacketChars)
            return ERROR_CODE;
    }


    return SUCCESS_CODE;
}

/* Perform decryption on the encrypted password using character addition.
 *
 * Each character is converted to an integer in the range 0...51, where a is 0,
 * b is 1, c is 2, ..., z is 25, A is 26, B is 27, ..., Z is 51.  The
 * decryption operation is then performed by adding the encryption key to the
 * encrypted password using addition modulo 52.
 *
 * Input: The encrypted password string and the encryption key are assumed
 *        to be valid and are assumed to be the same length (as verified
 *        by the process input function).
 *
 * Output:  The decrypted password generated by the above rules
 *
 * Assumptions: Both keys have been validated to have equal length and contain only
 *				alphabetic characters
 */
void decrypt_password(const char *encpw, const char *enckey, char *password)
{
    int i,j,strSize, validMap;
    const char *enc[NUM_PACKETS] = {encpw, enckey};

    strSize = cstrlen((char*)encpw);

    int encIntMap[NUM_PACKETS][strSize];
    int pwdIntMap[strSize];

    for(i = 0, validMap = 0; i < NUM_PACKETS; i++) {
        for(j = 0; j < strSize; j++) {
            validMap = mapCharInt((char*)enc[i],encIntMap[i]);
            if(!validMap) {
                printf("# ERROR: Invalid character mapped\n");
            }
        }
    }

    for(j = 0; j < strSize; j++) {
        pwdIntMap[j] = (encIntMap[0][j]+encIntMap[1][j]) % DECODE_MAP_LENGTH;
    }

    validMap = mapIntChar(strSize,pwdIntMap,password);

    if(!validMap) {
        printf("# ERROR: Invalid integer mapped\n");
    }

}


/* Find the length of the given string.
 *
 * Input: Pointer to character array of unknown length
 *
 * Output: Number of characters contained before escape character
 */
int cstrlen(char *str)
{
    int i=0, size=0;
    const int ERROR_CODE = -1;

    while(size<MAXPACKETSIZE) {
        if(*(str+i)=='\0') {
            return size;
        } else {
            size++;
        }
        i++;
    }

    return ERROR_CODE;

}

/* Copy string across arrays with some error checking
 *
 * Input: Pointer to character array with desired content
 *		  Pointer to character array with desired address
 *
 * Output: Success code of 1 if operation succeeds
 * 		   Error code of 0 if strings incompatible or operation fails
 */

int cstrcpy(const char *src, char *dest)
{
    int i, srcSize = 0;
    const int ERROR_CODE = 0, SUCCESS_CODE = 1;

    srcSize = cstrlen((char *)src);
    if(srcSize==-1)
        return ERROR_CODE;

    for(i = 0; i <= srcSize; i++) {
        *(dest+i) = *(src+i);
    }

    if(*(dest+i)=='\0')
        return SUCCESS_CODE;
    else
        return ERROR_CODE;
}

/* Find number of occurances of individual character
 *
 * Input: Pointer to character array with content to search
 *		  Character value to find in array
 *
 * Output: Integer containing number of occurrences
 *
 */

int cstrcharnum (const char *src, char toFind)
{
    int i, numChars = 0;
    const int ERROR_CODE = -1;

    int srcSize = cstrlen((char *)src);
    if(srcSize == -1)
        return ERROR_CODE;

    for(i=0; i<srcSize; i++)
        if(*(src+i)==toFind)
            numChars++;

    return numChars;
}


/* Find index of first occurance of individual character
 * value in source string
 *
 * Input: Pointer to character array with content to search
 * 		  Character value to find in array
 *
 * Output: Index if character value is found
 *		   Failure code if character is not found
 *  	   Error code if operation fails
 */

int cstrchar (const char *src, char toFind)
{
    int i=0;
    const int ERROR_CODE = -1, FAILURE_CODE = -2;

    int srcSize = cstrlen((char *)src);
    if(srcSize == -1)
        return ERROR_CODE;

    while(i<srcSize) {
        if(*(src+i)==toFind)
            return i;
        else
            i++;
    }

    return FAILURE_CODE;
}


/* Assemble three hidden parts of information into complete set
 *
 * Inputs: Pointer to character array with content to search
 * 		   3x2 integer array with rows corresponding to escape
 *				characters, columns corresponding to indices
 *		   Pointer to charracter array to store completed information set
 *
 * Output: SUCCESS_CODE 1 or FAILURE_CODE 0
 */

int assembleHidden(const char *src, int escIndex[NUM_ESCAPE_CHARS][NUM_INDICES], char *hiddenSet)
{
    int i,j,assemblyIndex,setSize;
    const int SUCCESS_CODE = 1;

    for(i = 0, assemblyIndex = 0; i < NUM_ESCAPE_CHARS; i++) {
        setSize = ((escIndex[i][1]-1) - (escIndex[i][0]+1) + 1);
        for(j = 0; j < setSize; j++, assemblyIndex++)
            *(hiddenSet+assemblyIndex) = *(src+(escIndex[i][0]+1)+j);
    }
    *(hiddenSet+assemblyIndex) = '\0';

    return SUCCESS_CODE;
}


/* Map characters to integers for decryption algorithm
 *
 * Input: Pointer to character array with characters to map
 *		  Pointer to integer array to store mapped characters
 *
 * Output: 1 if map successful
 *		   0 if map fails
 */

int mapCharInt(char *unmapped, int *mapped)
{
    int i, len;
    int validMap = 1;
    const int ERROR_CODE = 0, SUCCESS_CODE = 1;

    len = cstrlen(unmapped);

    for(i = 0; i < len; i++) {
        if(*(unmapped+i)>='a'&&*(unmapped+i)<='z') {
            *(mapped+i) = (int)(*(unmapped+i) - 'a');
        } else if(*(unmapped+i)>='A'&&*(unmapped+i)<='Z') {
            *(mapped+i) = (int)(*(unmapped+i) - 'A' + UPPERCASE_MAP_OFFSET);
        } else {
            validMap = 0;
        }
    }

    if(validMap)
        return SUCCESS_CODE;
    else
        return ERROR_CODE;
}


/* Map integers back to characters for decryption algorithm
 *
 * Input: Pointer to integer array containing mapped integers
 *		  Pointer to character array to store unmapped characters
 *
 * Output: 1 if map succeeds
 * 		   0 if map fails
 */

int mapIntChar(int mappedLen, int *mapped, char *unmapped)
{
    int i, validMap = 1;
    const int ERROR_CODE = 0, SUCCESS_CODE = 1;

    for(i = 0; i < mappedLen; i++) {
        if(*(mapped+i)>=0 && *(mapped+i)<(UPPERCASE_MAP_OFFSET)) {
            *(unmapped+i) = *(mapped+i) + 'a';
        } else if(*(mapped+i)>=(UPPERCASE_MAP_OFFSET) && *(mapped+i)<DECODE_MAP_LENGTH) {
            *(unmapped+i) = *(mapped+i) - UPPERCASE_MAP_OFFSET + 'A';
        } else {
            validMap = 0;
        }
    }
    *(unmapped+i) = '\0';

    if(validMap)
        return SUCCESS_CODE;
    else
        return ERROR_CODE;
}
